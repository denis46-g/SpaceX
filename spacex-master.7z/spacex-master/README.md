## Task

1. Add API methods to extract launchpads.
  
  API Docs: https://github.com/r-spacex/SpaceX-API/tree/master/docs#rspacex-api-docs

2. Add dots on the map for each launchpad.

  Use GeoJSON format and this code snippet:
  https://stackoverflow.com/questions/55406856/how-to-plot-lat-long-pairs-over-map-in-d3-js

3. Make list item active: when user hovers over the list item, highlight the launchpad that was used in this launch.


