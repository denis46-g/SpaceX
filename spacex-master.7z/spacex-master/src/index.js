import {SpaceX} from "./api/spacex";
import * as d3 from "d3";
import * as Geo from './geo.json'

document.addEventListener("DOMContentLoaded", setup)

let svg
let projection
const spaceX = new SpaceX();

function setup(){
    spaceX.launches().then(launches=>{
        const listContainer = document.getElementById("listContainer")
        renderLaunches(launches, listContainer);

        drawMap(spaceX.launchpads());

        //listContainer.addEventListener('mouseover', MakePointRed)
        let items = document.querySelector('#listContainer').querySelectorAll('li');
        items.forEach(item=>{
            item.addEventListener('mouseover', MakePointRed)
            item.addEventListener('mouseout', MakePointBlue)
        })
        //listContainer.removeEventListener('mouseover',setup)
    })
}
function renderLaunches(launches, container){
    const list = document.createElement("ul");
    launches.forEach(launch=>{
        const item = document.createElement("li");
        item.innerHTML = launch.name;
        list.appendChild(item);
    })
    container.replaceChildren(list);
}

function drawMap(launchpads){
    const width = 640;
    const height = 480;
    const margin = {top: 20, right: 10, bottom: 40, left: 100};
    svg = d3.select('#map').append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform",
            "translate(" + margin.left + "," + margin.top + ")");
    projection = d3.geoMercator()
        .scale(70)
        .center([0,20])
        .translate([width / 2 - margin.left, height / 2]);
    
    launchpads.then(l=>{
        l.forEach(ll=>{
            let lat = ll.latitude
            let long = ll.longitude
            let point = projection([long, lat])
            svg.append("circle")
                .attr("cx", point[0])
                .attr("cy", point[1])
                .attr("r", 5)
                .style("fill", "blue")
                .style("stroke", "blue")
        })
    })
    

    svg.append("g")
        .selectAll("path")
        .data(Geo.features)
        .enter()
        .append("path")
        .attr("class", "topo")
        .attr("d", d3.geoPath()
            .projection(projection)
        )
        .style("opacity", .7)
}

function MakePointRed(Event){
    let elem = Event.target

    spaceX.launches().then(launches=>{
        launches.forEach(launch=>{
            if(launch.name == elem["innerText"]){
                spaceX.launchpads().then(launchpads=>{
                    launchpads.forEach(launchpad=>{
                        if(launch.launchpad == launchpad.id){
                            let lat = launchpad.latitude
                            let long = launchpad.longitude
                            let point = projection([long, lat])
                            svg.append("circle")
                                .attr("cx", point[0])
                                .attr("cy", point[1])
                                .attr("r", 5)
                                .style("fill", "red")
                                .style("stroke", "red")
                        }
                    })
                })
            }
        })
    })
}

function MakePointBlue(Event){
    let elem = Event.target

    spaceX.launches().then(launches=>{
        launches.forEach(launch=>{
            if(launch.name == elem["innerText"]){
                spaceX.launchpads().then(launchpads=>{
                    launchpads.forEach(launchpad=>{
                        if(launch.launchpad == launchpad.id){
                            let lat = launchpad.latitude
                            let long = launchpad.longitude
                            let point = projection([long, lat])
                            svg.append("circle")
                                .attr("cx", point[0])
                                .attr("cy", point[1])
                                .attr("r", 5)
                                .style("fill", "blue")
                                .style("stroke", "blue")
                        }
                    })
                })
            }
        })
    })
}